<?php
$ukm = $this->db->query("SELECT * FROM ukm WHERE username = '" . $ukmid . "'")->row();
?>


<!-- ===== BERANDA ===== -->
<section id="beranda">
    <div class="container">
        <div class="row">
            <div class="col-md-6 me-2 col-beranda">

                <div class="be-text">
                    <h1>BBMK</h1>
                    <h2>2021</h2>
                </div>
                <button class="btn btnBeranda" type="button"><a href="register.html">Daftar Segera!</a></button>
            </div>
            <div class="col-auto beranda">
                <img src="<?= base_url(); ?>assets3/img/beranda.png" alt="BERANDA" />
            </div>
        </div>
    </div>
    <div class="row beranda-arrow">
        <a href="#pengenalan"> <i class="uil uil-angle-down"></i></a>
    </div>
</section>

<!-- Ukm -->
<section id="pengenalan">
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-5 pengenalanUKM">
                <img src="<?= base_url() ?>/assets/img/logo/<?= $ukm->logo ?>" style="width: 400px" alt="" />
                <p>“ <?= $ukm->deskripsi ?>”</p>
            </div>
            <div class="col-md-6 pengenalanUKM-head">
                <h2>APA ITU</h2>
                <h1><?= $ukm->nama ?></h1>
            </div>
        </div>
    </div>
</section>

<!-- Visi Misi -->
<section id="visimisi">
    <div class="container">
        <div class="row">
            <div class="col-md-5 visi-head align-middle">
                <h1>VISI & MISI</h1>
            </div>
            <div class="col-md-6 visi-misi">
                <div class="row visi">
                    <h5>Visi</h5>
                    <p>“ <?= $ukm->visi ?>”</p>
                </div>
                <div class="row misi mt-2">
                    <h5>Misi</h5>
                    <ol style="text-align: justify">
                        <?= $ukm->misi ?>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ===== AKHIR BERANDA ===== -->

<!-- ===== LINIMASA ===== -->
<section id="linimasa">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-6 linimasaFlow">
                <h4>Coming Soon</h4>
                <p>26 - 31 Oktober 2021</p>
                <h4>Pendaftaran</h4>
                <p>1 - 4 November 2021</p>
                <h4>Verifikasi</h4>
                <p>1 - 5 November 2021</p>
                <h4>Let’s BBMK Yeay!</h4>
                <p>6 - 28 November 2021</p>


                <?php
                if ($ukm->timeline1) { ?>
                    <h4>BBMK - 1</h4>
                    <p><?= $ukm->timeline1 ?></p>

                <?php
                }
                ?>
                <?php
                if ($ukm->timeline2) { ?>
                    <h4>BBMK - 2</h4>
                    <p><?= $ukm->timeline2 ?></p>

                <?php
                }
                ?>
                <?php
                if ($ukm->timeline3) { ?>
                    <h4>BBMK - 3</h4>
                    <p><?= $ukm->timeline3 ?></p>

                <?php
                }
                ?>
                <?php
                if ($ukm->timeline4) { ?>
                    <h4>BBMK - 3</h4>
                    <p><?= $ukm->timeline4 ?></p>

                <?php
                }
                ?>



            </div>
            <div class="col-md-6 linimasa">
                <h1>DOKUMENTASI</h1>
            </div>
        </div>
    </div>
</section>
<!-- ===== AKHIR LINIMASA ===== -->

<div class="container text-center mb-5">
    <iframe width="640px" height="360px" src="<?= $ukm->video ?>"> </iframe>
</div>

<!-- AKHIR UKM -->