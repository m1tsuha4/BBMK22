 <!-- Footer -->
 <footer>
     <div class="container">
         <div class="row">
             <div class="col bbmkFooter">
                 <img src="<?= base_url(); ?>assets3/img/bbmk.png" alt="Logo BBMK 2021" />
                 <br />
                 <div class="instaFooter mt-3">
                     <i class="uil uil-instagram iconInsta"></i>
                     <a href="https://www.instagram.com/bbmkonlineunand" target="_blank">bbmkonlineunand</a>
                 </div>
             </div>
             <div class="col-md-6 logoFooter">
                 <h4>Berkolabarasi Bersama</h4>
                 <img class="neo" src="<?= base_url(); ?>assets3/ukm/logo/neotelemetri.png" alt="Neo Telemetri" />
                 <img class="ukmp" src="<?= base_url(); ?>assets3/ukm/logo/ukmp.png" alt="UKMP" />
                 <img class="fki" src="<?= base_url(); ?>assets3/ukm/logo/rabbani.png" alt="FKI Rabbani" />
                 <img class="pandeka" src="<?= base_url(); ?>assets3/ukm/logo/pandekar.png" alt="Pandekar" />
                 <img class="kopma" src="<?= base_url(); ?>assets3/ukm/logo/kopma.png" alt="KOPMA" />
                 <img class="pikmag" src="<?= base_url(); ?>assets3/ukm/logo/pikmag.png" alt="PIKMAG" />
                 <img class="aiesec" src="<?= base_url(); ?>assets3/ukm/logo/aiesec.png" alt="AIESEC" />
                 <img class="genta" src="<?= base_url(); ?>assets3/ukm/logo/genta.png" alt="Genta " />
                 <img class="menwa" src="<?= base_url(); ?>assets3/ukm/logo/menwa.png" alt="Menwa" />
                 <img class="uko" src="<?= base_url(); ?>assets3/ukm/logo/uko.png" alt="UKO" />
                 <img class="pika" src="<?= base_url(); ?>assets3/ukm/logo/pika.png" alt="PIKA" />
                 <img class="kosbema" src="<?= base_url(); ?>assets3/ukm/logo/kosbema.png" alt="KOSBEMA" />
                 <img class="mapala" src="<?= base_url(); ?>assets3/ukm/logo/mapala.png" alt="MAPALA" />
                 <img class="ksr" src="<?= base_url(); ?>assets3/ukm/logo/ksrpmi.png" alt="KSR PMI" />
                 <img class="pramuka" src="<?= base_url(); ?>assets3/ukm/logo/pramuka.png" alt="Pramuka" />
                 <img class="sinema" src="<?= base_url(); ?>assets3/ukm/logo/sinema.png" alt="Sinematografi" />
                 <img class="hipmi" src="<?= base_url(); ?>assets3/ukm/logo/hipmi.png" alt="HIPMI" />
                 <img class="php" src="<?= base_url(); ?>assets3/ukm/logo/php.png" alt="PHP" />
                 <img class="uks" src="<?= base_url(); ?>assets3/ukm/logo/uks.png" alt="UKS" />
             </div>
             <div class="col akunCek">
                 <h4>Account Check</h4>
                 <input class="form-control form-control-sm textCheck" type="number" placeholder="NIM" aria-label="NIM" />
                 <button class="btn btnCheck" type="button">Check</button>
             </div>
         </div>
     </div>
     <!-- <div class="row mt-2 pt-2 md-0">
        <p>Bina Bakat Minat Kepemimpinan &#169; 2021</p>
      </div> -->
 </footer>
 <script src="<?= base_url(); ?>assets3/js/main.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

 <!-- assets sebelumnya -->
 <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <!-- Plugin JavaScript -->
 <script src="<?= base_url(); ?>assets/tmp/vendor/jquery-easing/jquery.easing.min.js"></script>
 <script src="<?= base_url(); ?>assets/tmp/vendor/scrollreveal/scrollreveal.min.js"></script>
 <script src="<?= base_url(); ?>assets/tmp/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

 <!-- Custom scripts for this template -->
 <script src="<?= base_url(); ?>assets/tmp/js/creative.min.js"></script>



 <!--  -->
 </body>

 </html>