      <!-- ===== PAGE CONTENT ===== -->
      <img src="<?= base_url(); ?>assets3/img/bg.png" alt="" class="bg-content" />
      <div class="container-fluid">
          <div class="col-md-6 offset-md-3 form-regis text-center edit-profile">
              <div class="">
                  <div class="d-flex justify-content-center">
                      <div class="profile-photo mt-5">
                          <img src="<?= base_url(); ?>assets3/ukm/logo_asli/NEOTELEMETRI.png" width="300" alt="" srcset="" />
                          <h2>UKM Neo Telemetri</h2>
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-6 mt-5 me-auto ms-auto text-center mb-5">
              <div class="row row-cols-2">
                  <div class="col cal-col">
                      <img src="<?= base_url(); ?>assets3/img/calendar.png" class="calender-icon" alt="" />
                      <h3>Day 1</h3>
                      <h5>07 November 2021</h5>
                      <p>Pembukaan materi departemen organisasi</p>
                  </div>
                  <div class="col cal-col">
                      <img src="<?= base_url(); ?>assets3/img/calendar.png" class="calender-icon" alt="" />
                      <h3>Day 2</h3>
                      <h5>07 November 2021</h5>
                      <p>Pembukaan materi departemen organisasi</p>
                  </div>
                  <div class="col cal-col mt-5">
                      <img src="<?= base_url(); ?>assets3/img/calendar.png" class="calender-icon" alt="" />
                      <h3>Day 3</h3>
                      <h5>07 November 2021</h5>
                      <p>Pembukaan materi departemen organisasi</p>
                  </div>
                  <div class="col cal-col mt-5">
                      <img src="<?= base_url(); ?>assets3/img/calendar.png" class="calender-icon" alt="" />
                      <h3>Day 4</h3>
                      <h5>07 November 2021</h5>
                      <p>Pembukaan materi departemen organisasi</p>
                  </div>
              </div>
          </div>
      </div>
      </div>
      </div>