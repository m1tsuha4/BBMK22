<?php

$user_ukm = $kelulusan;
$ukm = $this->db->query("SELECT * FROM ukm WHERE username = '" . $user_ukm . "'")->row();
// Peserta 2021
$jumlah_peserta21 = $this->db->query("SELECT* FROM peserta WHERE tahun ='2021' AND id_ukm ='$ukm->id'")->num_rows();
$jumlah_verif21 = $this->db->query("SELECT* FROM peserta WHERE stat_reg= 1 AND tahun ='2021'AND id_ukm ='$ukm->id'")->num_rows();
$jumlah_nonverif21 = $this->db->query("SELECT* FROM peserta WHERE stat_reg= 2 AND tahun ='2021' AND id_ukm ='$ukm->id' ")->num_rows();
$jumlah_belumverif21 = $this->db->query("SELECT* FROM peserta WHERE stat_reg= 0 AND tahun ='2021' AND id_ukm ='$ukm->id' ")->num_rows();

$jumlah_lulus21 = $this->db->query("SELECT* FROM peserta WHERE kelulusan= 1 AND tahun ='2021' AND id_ukm ='$ukm->id' ")->num_rows();
$jumlah_tidaklulus21 = $this->db->query("SELECT* FROM peserta WHERE kelulusan= 2 AND tahun ='2021' AND id_ukm ='$ukm->id' ")->num_rows();
$jumlah_belumlulus21 = $this->db->query("SELECT* FROM peserta WHERE kelulusan= 0 AND tahun ='2021' AND id_ukm ='$ukm->id' ")->num_rows();


// Peserta 2020
$jumlah_peserta20 = $this->db->query("SELECT* FROM peserta WHERE tahun is Null AND id_ukm ='$ukm->id' ")->num_rows();
$jumlah_verif20 = $this->db->query("SELECT* FROM peserta WHERE stat_reg= 1 AND tahun is Null AND id_ukm ='$ukm->id' ")->num_rows();
$jumlah_nonverif20 = $this->db->query("SELECT* FROM peserta WHERE stat_reg= 2 AND tahun is Null AND id_ukm ='$ukm->id' ")->num_rows();
$jumlah_belumverif20 = $this->db->query("SELECT* FROM peserta WHERE stat_reg= 0 AND tahun is Null AND id_ukm ='$ukm->id'")->num_rows();

$jumlah_lulus20 = $this->db->query("SELECT* FROM peserta WHERE kelulusan= 1 AND tahun is Null AND id_ukm ='$ukm->id' ")->num_rows();
$jumlah_tidaklulus20 = $this->db->query("SELECT* FROM peserta WHERE kelulusan= 2 AND tahun is Null AND id_ukm ='$ukm->id'")->num_rows();
$jumlah_belumlulus20 = $this->db->query("SELECT* FROM peserta WHERE kelulusan= 0 AND tahun is Null AND id_ukm ='$ukm->id'")->num_rows();

$peserta_20_lk = $this->db->query("SELECT* FROM peserta WHERE jk='Laki - Laki' AND tahun is null AND id_ukm ='$ukm->id'")->num_rows();
$peserta_20_p = $this->db->query("SELECT* FROM peserta WHERE jk='Perempuan' AND tahun is null AND id_ukm ='$ukm->id'")->num_rows();

$peserta_21_lk = $this->db->query("SELECT* FROM peserta WHERE jk='Laki - Laki' AND tahun ='2021' AND id_ukm ='$ukm->id'")->num_rows();
$peserta_21_p = $this->db->query("SELECT* FROM peserta WHERE jk='Perempuan' AND tahun ='2021' AND id_ukm ='$ukm->id'")->num_rows();
?>


<!-- Content Row - Jumlah Peserta -->
<div class="row mt-5">
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">

            <div class="row">
                <div class="col-md-6 pengenalanUKM-head" data-anijs="if: scroll, on: window, do: bounceInUp animated, before: scrollReveal repeat, after: scrollReveal">
                    <h1><?= $ukm->nama ?></h1>
                </div>
                <div class="col-md-5" data-anijs="if: scroll, on: window, do: bounceInDown animated, before: scrollReveal repeat, after: scrollReveal">
                    <img src="<?= base_url() ?>/assets/img/logo/<?= $ukm->logo ?>" style="width: 400px" alt="" />
                </div>
            </div>

        </div>
    </div>
</div>


<!-- Content Row - Jumlah Peserta -->
<div class="row mt-5">
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"> Statistik Peserta</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="pesertaGraph"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Peserta 2020</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="pesertaLulus20"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Peserta 2021</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="pesertaLulus21"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- ===== Content Row - Chart Peserta ===== -->
<div class="row">
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Kelulusan Peserta</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="passChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Pie Chart -->
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Verifikasi Peserta</h6>

            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-pie">
                    <canvas id="verifChart"></canvas>
                </div>

            </div>
        </div>
    </div>
</div>



<!-- grafik Fakultas -->
<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Peserta per Fakultas</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="fakultasChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>







<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js" integrity="sha512-d9xgZrVZpmmQlfonhQUvTR7lMPtO7NkZMkA0ABN3PHCbKA5nqylQ/yWlFAyY6hYgdF1Qh6nYiuADWwKB4C2WSw==" crossorigin="anonymous"></script>
<script>
    new Chart(document.getElementById("verifChart"), {
        type: 'bar',
        data: {
            labels: ["Diverifikasi", "Belum Diverifikasi", "Tidak Diverifikasi"],
            datasets: [{
                    label: "Peserta 2021",
                    backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850", "#ffc93c", "#dbf6e9", "#9ddfd3", "#31326f", "#31326f", "#e84545", "#903749", "#53354a", "#f39189", "#bb8082", "#6e7582", "#046582", "#f8f5f1", "#1f441e", "#cee6b4"],
                    data: [
                        <?php
                        echo ($jumlah_verif21 . ',');
                        echo ($jumlah_belumverif21 . ',');
                        echo ($jumlah_nonverif21 . ',');

                        ?>
                    ]
                },
                {
                    label: "Peserta 2020",
                    backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850", "#ffc93c", "#dbf6e9", "#9ddfd3", "#31326f", "#31326f", "#e84545", "#903749", "#53354a", "#f39189", "#bb8082", "#6e7582", "#046582", "#f8f5f1", "#1f441e", "#cee6b4"],
                    data: [
                        <?php
                        echo ($jumlah_verif20 . ',');
                        echo ($jumlah_belumverif20 . ',');
                        echo ($jumlah_nonverif20 . ',');

                        ?>
                    ]
                }
            ]
        },
        options: {
            title: {
                display: true,
                text: 'Total Participant'
            }
        }
    });


    // kelulusan
    new Chart(document.getElementById("passChart"), {
        type: 'bar',
        data: {
            labels: ["Lulus", "Tidak Lulus", "Belum Lulus"],
            datasets: [{
                label: "Peserta 2020",
                backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850", "#ffc93c", "#dbf6e9", "#9ddfd3", "#31326f", "#31326f", "#e84545", "#903749", "#53354a", "#f39189", "#bb8082", "#6e7582", "#046582", "#f8f5f1", "#1f441e", "#cee6b4"],
                data: [
                    <?php

                    echo ($jumlah_lulus21 . ',');
                    echo ($jumlah_tidaklulus21 . ',');
                    echo ($jumlah_belumlulus21 . ',');

                    ?>

                ]
            }, {
                label: "Peserta 2021",
                backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850", "#ffc93c", "#dbf6e9", "#9ddfd3", "#31326f", "#31326f", "#e84545", "#903749", "#53354a", "#f39189", "#bb8082", "#6e7582", "#046582", "#f8f5f1", "#1f441e", "#cee6b4"],
                data: [
                    <?php

                    echo ($jumlah_lulus20 . ',');
                    echo ($jumlah_tidaklulus20 . ',');
                    echo ($jumlah_belumlulus20 . ',');

                    ?>

                ]
            }]
        },
        options: {
            title: {
                display: true,
                text: 'Total Participant Passed'
            }
        }
    });



    // jurusan
    new Chart(document.getElementById("fakultasChart"), {
        type: 'bar',
        data: {
            labels: [
                <?php
                $xquery = $this->db->query("SELECT * FROM fakultas");
                $no_ukm = 1;
                foreach ($xquery->result() as $fakultas) {
                    echo ('"' . $fakultas->fakultas . '",');
                }
                ?>
            ],
            datasets: [{
                    label: "Peserta Tahun 2021",
                    backgroundColor: ["#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", "#3e95cd", ],
                    data: [
                        <?php
                        $xquery = $this->db->query("SELECT * FROM fakultas");
                        $no_ukm = 1;
                        foreach ($xquery->result() as $fakultas) {
                            $peserta = $this->db->query("SELECT* FROM peserta WHERE fakultas ='$fakultas->id'and tahun=2021 AND id_ukm ='$ukm->id' ");
                            echo ($peserta->num_rows() . ',');
                        }
                        ?>

                    ]
                },
                {
                    label: "Peserta Tahun 2020 ",
                    backgroundColor: ["#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", "#8e5ea2", ],
                    data: [
                        <?php
                        $xquery = $this->db->query("SELECT * FROM fakultas");
                        $no_ukm = 1;
                        foreach ($xquery->result() as $fakultas) {
                            $peserta = $this->db->query("SELECT* FROM peserta WHERE fakultas ='$fakultas->id'and tahun is null AND id_ukm ='$ukm->id'");
                            echo ($peserta->num_rows() . ',');
                        }
                        ?>

                    ]
                }
            ]
        },
        options: {
            title: {
                display: true,
                text: 'Fakultas Peserta BBMK 2021'
            }
        }
    });



    new Chart(document.getElementById("pesertaGraph"), {
        type: 'bar',
        data: {
            labels: ["Laki-laki", "Perempuan"],
            datasets: [{
                    label: "Peserta 2021",
                    backgroundColor: ["#3e95cd", "#3e95cd", "#3e95cd"],
                    data: [
                        <?php
                        echo ($peserta_21_lk . ',');
                        echo ($peserta_21_p . ',');
                        ?>
                    ]
                },
                {
                    label: "Peserta 2020",
                    backgroundColor: ["#c45850", "#c45850", "#c45850"],
                    data: [
                        <?php
                        echo ($peserta_20_lk . ',');
                        echo ($peserta_20_p . ',');
                        ?>
                    ]
                }
            ]
        },
        options: {
            title: {
                display: true,
                text: 'Total Participant'
            }
        }
    });

    new Chart(document.getElementById("pesertaLulus20"), {
        type: 'pie',
        data: {
            labels: ["Peserta Lulus", "Peserta Belum Lulus", "Peserta Tidak lulus"],
            datasets: [{
                label: "Peserta 2022",
                backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f"],
                data: [
                    <?php
                    echo ($jumlah_lulus20 . ',');
                    echo ($jumlah_belumlulus20 . ',');
                    echo ($jumlah_tidaklulus20 . ',');
                    ?>
                ]
            }]
        },
        options: {
            title: {
                display: true,
                text: 'Total Participant'
            }
        }
    });


    new Chart(document.getElementById("pesertaLulus21"), {
        type: 'pie',
        data: {
            labels: ["Peserta Lulus", "Peserta Belum Lulus", "Peserta Tidak lulus"],
            datasets: [{
                label: "Peserta 2022",
                backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f"],
                data: [
                    <?php
                    echo ($jumlah_lulus21 . ',');
                    echo ($jumlah_belumlulus21 . ',');
                    echo ($jumlah_tidaklulus21 . ',');
                    ?>
                ]
            }]
        },
        options: {
            title: {
                display: true,
                text: 'Total Participant'
            }
        }
    });
</script>